// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

// ---------------------------------------------------------
// EXERCISE: Unused
//
//  1. Declare a variable
//
//  2. Variable's name should be: isLiquid
//
//  3. Discard it using a blank-identifier
//
// NOTE
//  Do not print the variable
// ---------------------------------------------------------

func main() {
}

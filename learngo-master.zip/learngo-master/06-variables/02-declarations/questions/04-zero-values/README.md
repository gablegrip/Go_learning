## Which type's zero value is 0?
- bool
- pointer
- string
- all numeric types *CORRECT*

## Which type's zero value is false?
- bool *CORRECT*
- pointer
- string
- all numeric types

## Which type's zero value is ""?
- bool
- pointer
- string *CORRECT*
- all numeric types

## Which type's zero value is nil?
- bool
- pointer *CORRECT*
- string
- all numeric types

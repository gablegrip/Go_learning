# QUESTIONS: What's a variable?

## Where does a variable live?
* Hard Disk
* Computer Memory - *CORRECT*
* CPU

## What do you use a variable's name for?
* To be able to access it later - *CORRECT*
* It's just a label
* I don't need to use it

## How to change the value of a variable?
* By using its name - *CORRECT*
* By using its value
* By asking to Go
 
## After its declaration can you change the variable's type?
* Yes : Go is dynamically-typed
* No  : Go is statically-typed - *CORRECT*
* Both: Go supports both of them


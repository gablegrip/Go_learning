## What happens when you don't use a declared variable in the block scope?
* Nothing, it will work fine
* It will get removed automatically
* The program won't compile *CORRECT*

## What happens when you don't use a declared variable in the package scope?
* Nothing, it will work fine *CORRECT*
* It will get removed automatically
* The program won't compile

## How can you prevent unused variable error?
* You can change the variable's name
* You can use a blank-identifier to discard it *CORRECT*
* You can change the variable's type
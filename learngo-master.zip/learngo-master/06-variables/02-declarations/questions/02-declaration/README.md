## Which statement do you need to use for declaring variables?
* name int
* vars string name
* var name integer
* var width int *CORRECT*

## Which sentence below is correct?
* You can use a variable before declaring it
* You have to declare a variable before using it *CORRECT*

## What kind of language is Go?
* Weakly-Typed
* Dynamically-Typed
* Strongly-Typed *CORRECT*
* Freely-Typed

## Which variable name below is correct?
* int
* four *CORRECT*
* 2computers
* one?there
// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

// there's no warning for package-level vars
var packageLevelVar string

func main() {
	// unused variable error
	// var speed int

	// if you use it, the error will be gone
	// fmt.Println(speed)
}

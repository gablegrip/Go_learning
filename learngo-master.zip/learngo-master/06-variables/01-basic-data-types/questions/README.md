## Which one below is an integer literal?
* -42 *CORRECT*
    * This is an integer literal
* "Hello"
    * This is a string literal
* false
    * This is a bool constant
* 3.14
    * This is a float literal

## Which one below is a float literal?
* -42
* "Hello"
* false
* 3.14 *CORRECT*

## Which one below is a float literal?
* 6,28
* ,28
* .28 *CORRECT*
* 628

## Which one below is a string literal?
* -42
* "Hello" *CORRECT*
* false
* 3.14

## Which one below is a bool constant?
* -42
* "Hello"
* false *CORRECT*
* 3.14

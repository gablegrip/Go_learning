1. **[Print the literals](https://github.com/inancgumus/learngo/tree/master/06-variables/01-basic-data-types/exercises/01-print-the-literals)**

    Print a few values using the literals

2. **[Print hexes](https://github.com/inancgumus/learngo/tree/master/06-variables/01-basic-data-types/exercises/02-print-hexes)** (optional exercise)

    Print numbers in hexadecimal

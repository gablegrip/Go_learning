# Command Line Arguments

1. **[Count the Arguments](https://github.com/inancgumus/learngo/tree/master/06-variables/06-project-greeter/exercises/01-count-arguments)**

2. **[Print the Path](https://github.com/inancgumus/learngo/tree/master/06-variables/06-project-greeter/exercises/02-print-the-path)**

3. **[Print Your Name](https://github.com/inancgumus/learngo/tree/master/06-variables/06-project-greeter/exercises/03-print-your-name)**

4. **[Greet More People](https://github.com/inancgumus/learngo/tree/master/06-variables/06-project-greeter/exercises/04-greet-more-people)**

5. **[Greet 5 People](https://github.com/inancgumus/learngo/tree/master/06-variables/06-project-greeter/exercises/05-greet-5-people)**

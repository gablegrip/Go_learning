# Short Declare

Time to declare a few variables using the short declaration syntax. You'll also use the redeclaration and discarding.

1. **[Short Declare](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/01-short-declare)**

2. **[Multiple Short Declare](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/02-multiple-short-declare)**

3. **[Multiple Short Declare #2](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/03-multiple-short-declare-2)**

4. **[Short With Expression](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/04-short-with-expression)**

5. **[Short Discard](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/05-short-discard)**

6. **[Redeclare](https://github.com/inancgumus/learngo/tree/master/06-variables/03-short-declaration/exercises/06-redeclare)**
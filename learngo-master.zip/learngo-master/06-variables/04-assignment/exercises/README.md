# Assignments

Assignment means "copying" values. Everything is getting copied in Go. You'll learn more about this afterward.

Now, get your feet wet and try some assignment exercises.

1. **[Make It Blue](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/01-make-it-blue)**

2. **[Variables To Variables](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/02-vars-to-vars)**

3. **[Assign With Expressions](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/03-assign-with-expressions)**

4. **[Find the Rectangle's Perimeter](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/04-find-the-rectangle-perimeter)**

5. **[Multi Assign](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/05-multi-assign)**

6. **[Multi Assign #2](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/06-multi-assign-2)**

7. **[Multi Short Func](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/07-multi-short-func)**

8. **[Swapper](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/08-swapper)**

9. **[Swapper #2](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/09-swapper-2)**

10. **[Discard The File](https://github.com/inancgumus/learngo/tree/master/06-variables/04-assignment/exercises/10-discard-the-file)**

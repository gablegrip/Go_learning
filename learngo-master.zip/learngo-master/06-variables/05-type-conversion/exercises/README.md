# Type Conversion

Here are 5 exercises for you. You must find the errors and then fix them using the correct type conversions.

1. **[Convert and Fix #1](https://github.com/inancgumus/learngo/tree/master/06-variables/05-type-conversion/exercises/01-convert-and-fix)**

2. **[Convert and Fix #2](https://github.com/inancgumus/learngo/tree/master/06-variables/05-type-conversion/exercises/02-convert-and-fix-2)**

3. **[Convert and Fix #3](https://github.com/inancgumus/learngo/tree/master/06-variables/05-type-conversion/exercises/03-convert-and-fix-3)**

4. **[Convert and Fix #4](https://github.com/inancgumus/learngo/tree/master/06-variables/05-type-conversion/exercises/04-convert-and-fix-4)**

5. **[Convert and Fix #5](https://github.com/inancgumus/learngo/tree/master/06-variables/05-type-conversion/exercises/05-convert-and-fix-5)**

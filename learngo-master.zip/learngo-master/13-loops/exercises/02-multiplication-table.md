# Multiplication Table

1. **[Dynamic Table](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/07-multiplication-table-exercises/01-dynamic-table)**

2. **[Math Table](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/07-multiplication-table-exercises/02-math-tables)**
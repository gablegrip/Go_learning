# Word Finder

1. **[Case Insensitive Search](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/09-word-finder-exercises/01-case-insensitive)**

2. **[Path Searcher](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/09-word-finder-exercises/02-path-searcher)**
# Crunch the Primes

1. **[Crunch the primes](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/10-crunch-the-primes)**

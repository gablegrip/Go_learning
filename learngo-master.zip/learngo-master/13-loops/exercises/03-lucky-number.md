# Lucky Number

1. **[First Turn Winner](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/01-first-turn-winner)**

2. **[Random Messages](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/02-random-messages)**

3. **[Double Guesses](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/03-double-guesses)**

4. **[Verbose Mode](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/04-verbose-mode)**

5. **[Enough Picks](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/05-enough-picks)**

6. **[Dynamic Difficulty](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/08-lucky-number-exercises/06-dynamic-difficulty)**
# Loops

1. **[Sum the Numbers](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/01-sum-the-numbers)**

2. **[Sum the Numbers: Verbose Edition](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/02-sum-the-numbers-verbose)**

3. **[Sum up to N](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/03-sum-up-to-n)**

4. **[Only Evens](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/04-only-evens)**

5. **[Break Up](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/05-break-up)**

6. **[Infinite Kill](https://github.com/inancgumus/learngo/tree/master/13-loops/exercises/06-infinite-kill)**
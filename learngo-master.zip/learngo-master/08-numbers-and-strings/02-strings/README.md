# Basic Strings

1. **[Windows Path](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/01-windows-path)**

2. **[Print JSON](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/02-print-json)**

3. **[Raw Concat](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/03-raw-concat)**

4. **[Count the Chars](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/04-count-the-chars)**

5. **[Improved Banger](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/05-improved-banger)**

6. **[ToLowercase](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/06-tolowercase)**

7. **[Trim It](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/07-trim-it)**

8. **[Right Trim It](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/02-strings/exercises/08-right-trim-it)**


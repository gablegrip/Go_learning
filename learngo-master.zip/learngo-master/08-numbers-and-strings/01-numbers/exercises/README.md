# Numbers, Precedence, and Assignment Operations

1. **[Do Some Calculations](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/01-do-some-calculations)**

2. **[Fix the Float](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/02-fix-the-float)**

3. **[Precedence](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/03-precedence)**

4. **[IncDecs](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/04-incdecs)**

5. **[Manipulate a Counter](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/05-manipulate-a-counter)**

6. **[Simplify the Assignments](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/06-simplify-the-assignments)**

7. **[Circle Area](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/07-circle-area)**

8. **[Sphere Area](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/08-sphere-area)**

9. **[Sphere Volume](https://github.com/inancgumus/learngo/tree/master/08-numbers-and-strings/01-numbers/exercises/09-sphere-volume)**

// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

import "fmt"

func main() {
	// remove the comments and run
	// I've commented the lines it's because of the warnings

	// fmt.Println("true  || true  =", true || true)
	fmt.Println("true  || false =", true || false)
	fmt.Println("false || true  =", false || true)
	// fmt.Println("false || false =", false || false)
}

# If Statement

1. **[Age Seasons](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/01-age-seasons)**

2. **[Simplify It](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/02-simplify-it)**

3. **[Arg Count](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/03-arg-count)**

4. **[Vowel or Consonant](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/04-vowel-or-cons)**

## Error Handling

5. **[Movie Ratings](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/05-movie-ratings)**

6. **[Odd or Even](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/06-odd-even)**

7. **[Leap Year](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/07-leap-year)**

8. **[Simplify the Leap Year](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/08-simplify-leap-year)**

9. **[Days in a Month](https://github.com/inancgumus/learngo/tree/master/11-if/exercises/09-days-in-month)**


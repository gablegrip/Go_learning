# GO INSTALLATION GUIDES

Please select your operating system below for the detailed installation instructions:

* [OS X](osx-installation.md)
* [Windows](windows-installation.md)
* [Linux (Ubuntu)](ubuntu-installation.md)

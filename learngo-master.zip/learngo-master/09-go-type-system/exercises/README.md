# Types

1. **[Find the Optimal Types](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/01-optimal-types)**

2. **[Fix the Type Problem](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/02-the-type-problem)**

3. **[Parse Arg Numbers](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/03-parse-arg-numbers)**

4. **[Time Multiplier](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/04-time-multiplier)**

5. **[Refactor Feet to Meter](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/05-refactor-feet-to-meter)**

6. **[Convert the Types](https://github.com/inancgumus/learngo/tree/master/09-go-type-system/exercises/06-convert-the-types)**
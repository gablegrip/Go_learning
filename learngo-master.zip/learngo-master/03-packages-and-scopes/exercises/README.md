1. **[Use your own package](https://github.com/inancgumus/learngo/tree/master/03-packages-and-scopes/exercises/01-packages)**

    Create a few Go files and call their functions from the main function.


2. **[Try the scopes](https://github.com/inancgumus/learngo/tree/master/03-packages-and-scopes/exercises/02-scopes)**

    Learn the effects of scoping across packages.


3. **[Rename imports](https://github.com/inancgumus/learngo/tree/master/03-packages-and-scopes/exercises/03-importing)**

    Import the same package using a different name.
// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

// Uncomment below code to see the error
// (Just remove the // characters for all 3 lines below)

// This file cannot see main.go's imported names ("fmt").
// Because the imported names belong to file scope.

// func bye() {
// 	fmt.Println("Bye!")
// }

# Switch Statement

1. **[Richter Scale](https://github.com/inancgumus/learngo/tree/master/12-switch/exercises/01-richter-scale)**

2. **[Richter Scale #2](https://github.com/inancgumus/learngo/tree/master/12-switch/exercises/02-richter-scale-2)**

3. **[Convert](https://github.com/inancgumus/learngo/tree/master/12-switch/exercises/03-convert)**

4. **[String Manipulator](https://github.com/inancgumus/learngo/tree/master/12-switch/exercises/04-string-manipulator)**

5. **[Days in a Month](https://github.com/inancgumus/learngo/tree/master/12-switch/exercises/05-days-in-month)**

## EXERCISE

- Print the documentation of `runtime.NumCPU` function in the command line
- Print also its source code using in the command line

## HINT

You should use correct `go doc` tools

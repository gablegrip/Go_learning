## DOCUMENTATION:

  go doc runtime NumCPU

## SOURCE CODE:

  go doc -src runtime NumCPU

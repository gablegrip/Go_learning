// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

func main() {
	// Uncomment the line of code below; then save the file.
	//
	// You will see that Gofmt tool will format your code automatically.
	// https://golang.org/cmd/gofmt/
	//
	// This is because, for Go, it doesn't matter whether
	// you use semicolons between the statements or not.
	//
	// It adds them automatically after all.

	/*
		fmt.Println("inanc"); fmt.Println("lina"); fmt.Println("ebru");
	*/
}

// Copyright © 2018 Inanc Gumus
// Learn Go Programming Course
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// For more tutorials  : https://learngoprogramming.com
// In-person training  : https://www.linkedin.com/in/inancgumus/
// Follow me on twitter: https://twitter.com/inancgumus

package main

// ---------------------------------------------------------
// EXERCISE: Naked Expression
//
//  1. Try to type just "Hello" on a line.
//  2. Do not use Println
//  3. Observe the error
//
// ---------------------------------------------------------

func main() {
	// ?
}

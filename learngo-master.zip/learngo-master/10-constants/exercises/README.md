# Constants

1. **[Minutes in Weeks](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/01-minutes-in-weeks)**

2. **[Remove the Magic](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/02-remove-the-magic)**

3. **[Constant Length](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/03-constant-length)**

4. **[TAU](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/04-tau)**

5. **[Area](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/05-area)**

6. **[No Conversions Allowed](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/06-no-conversions-allowed)**

7. **[Iota Months](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/07-iota-months)**

8. **[Iota Months #2](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/08-iota-months-2)**

9. **[Iota Seasons](https://github.com/inancgumus/learngo/tree/master/10-constants/exercises/09-iota-seasons)**


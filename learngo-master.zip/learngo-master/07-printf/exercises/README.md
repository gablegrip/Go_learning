# Printf

1. **[Print Your Age](https://github.com/inancgumus/learngo/tree/07-printf/exercises/01-print-your-age)**

2. **[Print Your Name and LastName](https://github.com/inancgumus/learngo/tree/07-printf/exercises/02-print-your-name-and-lastname)**

3. **[False Claims](https://github.com/inancgumus/learngo/tree/07-printf/exercises/03-false-claims)**

4. **[Print the Temperature](https://github.com/inancgumus/learngo/tree/07-printf/exercises/04-print-the-temperature)**

5. **[Double Quotes](https://github.com/inancgumus/learngo/tree/07-printf/exercises/05-double-quotes)**

6. **[Print the Type](https://github.com/inancgumus/learngo/tree/07-printf/exercises/06-print-the-type)**

7. **[Print the Type #2](https://github.com/inancgumus/learngo/tree/07-printf/exercises/07-print-the-type-2)**

8. **[Print the Type #3](https://github.com/inancgumus/learngo/tree/07-printf/exercises/08-print-the-type-3)**

9. **[Print the Type #4](https://github.com/inancgumus/learngo/tree/07-printf/exercises/09-print-the-type-4)**

10. **[Print Your Fullname](https://github.com/inancgumus/learngo/tree/07-printf/exercises/10-print-your-fullname)**
